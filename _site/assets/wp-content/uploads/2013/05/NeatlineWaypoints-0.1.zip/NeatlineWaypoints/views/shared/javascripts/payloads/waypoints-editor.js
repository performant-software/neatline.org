
/* vim: set expandtab tabstop=2 shiftwidth=2 softtabstop=2 cc=76; */

/**
 * @package     omeka
 * @subpackage  neatline-Waypoints
 * @copyright   2012 Rector and Board of Visitors, University of Virginia
 * @license     http://www.apache.org/licenses/LICENSE-2.0.html
 */

Neatline.module('Waypoints', function(
  Waypoints, Neatline, Backbone, Marionette, $, _) {


  Waypoints.ID = 'WAYPOINTS';


  Waypoints.addInitializer(function() {
    Waypoints.__collection = new Neatline.Shared.Record.Collection();
    Waypoints.__view = new Waypoints.View();
    Neatline.execute(Waypoints.ID+':load');
  });


});


/* vim: set expandtab tabstop=2 shiftwidth=2 softtabstop=2 cc=76; */

/**
 * @package     omeka
 * @subpackage  neatline-Waypoints
 * @copyright   2012 Rector and Board of Visitors, University of Virginia
 * @license     http://www.apache.org/licenses/LICENSE-2.0.html
 */

Neatline.module('Waypoints', function(
  Waypoints, Neatline, Backbone, Marionette, $, _) {


  /**
   * Load waypoint records, ordered by weight.
   */
  var load = function() {

    var params = {
      widget: 'Waypoints', order: 'weight'
    };

    Waypoints.__collection.update(params, function(records) {
      ingest(records);
    });

  };
  Neatline.commands.setHandler(Waypoints.ID+':load', load);
  Neatline.vent.on('refresh', load);


  /**
   * Render a records collection in the list.
   *
   * @param {Object} records: The collection of records.
   */
  var ingest = function(records) {
    Waypoints.__view.ingest(records);
  };
  Neatline.commands.setHandler(Waypoints.ID+':ingest', ingest);


});


/* vim: set expandtab tabstop=2 shiftwidth=2 softtabstop=2 cc=76; */

/**
 * @package     omeka
 * @subpackage  neatline-Waypoints
 * @copyright   2012 Rector and Board of Visitors, University of Virginia
 * @license     http://www.apache.org/licenses/LICENSE-2.0.html
 */

Neatline.module('Waypoints', function(
  Waypoints, Neatline, Backbone, Marionette, $, _) {


  Waypoints.View = Neatline.Shared.Widget.View.extend({


    id: 'waypoints',

    events: {
      'mouseenter a': 'onHighlight',
      'mouseleave a': 'onUnhighlight',
      'click a': 'onSelect'
    },


    /**
     * Compile the records template.
     */
    init: function() {
      this.template = _.template(
        $('#waypoints-public-list-template').html()
      );
    },


    /**
     * Render a list of records.
     *
     * @param {Object} records: The records collection.
     */
    ingest: function(records) {
      this.$el.toggleClass('empty', records.length == 0);
      this.$el.html(this.template({ records: records }));
    },


    /**
     * Highlight presenter on hover.
     *
     * @param {Object} e: The DOM event.
     */
    onHighlight: function(e) {
      Neatline.vent.trigger('highlight', {
        source: Waypoints.ID,
        model: this.getModel(e)
      });
    },


    /**
     * Unhighlight presenter on unhover.
     *
     * @param {Object} e: The DOM event.
     */
    onUnhighlight: function(e) {
      Neatline.vent.trigger('unhighlight', {
        source: Waypoints.ID,
        model: this.getModel(e)
      });
    },


    /**
     * Select when a record is clicked.
     *
     * @param {Object} e: The DOM event.
     */
    onSelect: function(e) {
      Neatline.vent.trigger('select', {
        source: Waypoints.ID,
        model: this.getModel(e)
      });
    },


    /**
     * Get the model for a DOM event.
     *
     * @param {Object} e: The DOM event.
     */
    getModel: function(e) {
      return Waypoints.__collection.get(
        parseInt($(e.currentTarget).attr('data-id'), 10)
      );
    }


  });


});


/* vim: set expandtab tabstop=2 shiftwidth=2 softtabstop=2 cc=76; */

/**
 * @package     omeka
 * @subpackage  neatline-Waypoints
 * @copyright   2012 Rector and Board of Visitors, University of Virginia
 * @license     http://www.apache.org/licenses/LICENSE-2.0.html
 */

Neatline.module('Editor.Exhibit.Waypoints', function(
  Waypoints, Neatline, Backbone, Marionette, $, _) {


  Waypoints.ID = 'EDITOR:WAYPOINTS';


  Waypoints.addInitializer(function() {
    Waypoints.__collection  = new Neatline.Shared.Record.Collection();
    Waypoints.__router      = new Waypoints.Router();
    Waypoints.__view        = new Waypoints.View();
  });


});


/* vim: set expandtab tabstop=2 shiftwidth=2 softtabstop=2 cc=76; */

/**
 * @package     omeka
 * @subpackage  neatline-Waypoints
 * @copyright   2012 Rector and Board of Visitors, University of Virginia
 * @license     http://www.apache.org/licenses/LICENSE-2.0.html
 */

Neatline.module('Editor.Exhibit.Waypoints', function(
  Waypoints, Neatline, Backbone, Marionette, $, _) {


  /**
   * Display the form and update the sorting list.
   *
   * @param {Object} container: The container element.
   */
  var display = function(container) {

    Waypoints.__view.showIn(container);

    var params = {
      widget: 'waypoints', order: 'weight'
    };

    Waypoints.__collection.update(params, function(records) {
      Waypoints.__view.ingest(records);
    });

  };
  Neatline.commands.setHandler(Waypoints.ID+':display', display);


});


/* vim: set expandtab tabstop=2 shiftwidth=2 softtabstop=2 cc=76; */

/**
 * @package     omeka
 * @subpackage  neatline-Waypoints
 * @copyright   2012 Rector and Board of Visitors, University of Virginia
 * @license     http://www.apache.org/licenses/LICENSE-2.0.html
 */

Neatline.module('Editor.Exhibit.Waypoints', function(
  Waypoints, Neatline, Backbone, Marionette, $, _) {


  Waypoints.Router = Neatline.Editor.Router.extend({


    routes: {
      waypoints: 'waypoints'
    },


    /**
     * Show the waypoints sorting form.
     */
    waypoints: function() {

      Neatline.execute('EDITOR:display', [
        'EDITOR:EXHIBIT',
        'EDITOR:WAYPOINTS'
      ]);

      Neatline.execute(
        'EDITOR:EXHIBIT:activateTab', 'waypoints'
      );

    }


  });


});


/* vim: set expandtab tabstop=2 shiftwidth=2 softtabstop=2 cc=76; */

/**
 * @package     omeka
 * @subpackage  neatline-Waypoints
 * @copyright   2012 Rector and Board of Visitors, University of Virginia
 * @license     http://www.apache.org/licenses/LICENSE-2.0.html
 */

Neatline.module('Editor.Exhibit.Waypoints', function(
  Waypoints, Neatline, Backbone, Marionette, $, _) {


  Waypoints.View = Backbone.Neatline.View.extend({


    template:   '#waypoints-form-template',
    className:  'form-stacked waypoints',
    tagName:    'form',

    events: {
      'click a[name="save"]': 'save'
    },

    ui: {
      save: 'a[name="save"]',
      list: 'div.sort'
    },


    /**
     * Instantiate Sortable, compile the records template.
     */
    init: function() {
      this.__ui.list.sortable();
      this.template = _.template(
        $('#waypoints-editor-list-template').html()
      );
    },


    /**
     * Render a list of records.
     *
     * @param {Object} records: The records collection.
     */
    ingest: function(records) {

      // Render the record list.
      this.__ui.list.html(this.template({ records: records }));

      // (En/dis)able Sortable, "Save" button.
      if (records.length > 0) this.enableSorting();
      else this.disableSorting();

      // Store collection.
      this.records = records;

    },


    /**
     * Save the order.
     */
    save: function() {

      // Break if collection is empty.
      if (this.records.length == 0) return;

      $.ajax({
        data:     JSON.stringify(this.getOrder()),
        url:      Neatline.global.waypoints_api,
        success:  _.bind(this.onSaveSuccess, this),
        error:    _.bind(this.onSaveError, this),
        type:     'POST'
      });

    },


    /**
     * Enable Sortable and the "Save" button.
     */
    enableSorting: function() {
      this.__ui.list.sortable('enable');
      this.__ui.save.removeClass('disabled');
    },


    /**
     * Disable Sortable and the "Save" button.
     */
    disableSorting: function() {
      this.__ui.list.sortable('disable');
      this.__ui.save.addClass('disabled');
    },


    /**
     * Gather the record order as an array of id's.
     */
    getOrder: function() {
      return this.__ui.list.sortable('toArray', {
        attribute: 'data-id'
      });
    },


    /**
     * When a save succeeds.
     */
    onSaveSuccess: function() {

      // Refresh the exhibit.
      Neatline.vent.trigger('refresh', {
        source: Waypoints.ID
      })

      // Flash success message.
      Neatline.execute('EDITOR:notifySuccess',
        WP_STRINGS.order.save.success
      );

    },


    /**
     * When a save fails.
     */
    onSaveError: function() {

      // Flash error message.
      Neatline.execute('EDITOR:notifyError',
        WP_STRINGS.order.save.error
      );

    }


  });


});
