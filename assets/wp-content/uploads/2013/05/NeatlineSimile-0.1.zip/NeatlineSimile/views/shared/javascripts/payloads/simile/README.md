# SIMILE Timeline

Load SIMILE Timeline locally:

```html
<head>
  <script src="ajax/simile-ajax-api.js?bundle=true"></script>
  <script src="js/timeline-api.js?bundle=true"></script>
</head>
```
