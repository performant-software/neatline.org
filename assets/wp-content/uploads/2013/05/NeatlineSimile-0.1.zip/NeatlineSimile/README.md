# NeatlineSIMILE

Add [SIMILE Timeline](http://www.simile-widgets.org/timeline/) to Neatline exhibits.
